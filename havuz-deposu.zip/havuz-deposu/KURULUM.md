# Havuzu telefondan kurtarma — 15 dakikalık tek seferlik kurulum

Havuz artık **GitHub'ın sunucusunda** kurulur, telefon sadece hazır dosyayı çeker.
Kullanıcı hiçbir şey beklemez, hiçbir düğmeye basmaz.

```
GitHub Actions (gece 04:00)      →  havuz.json  →  telefon (2 saniye)
sayfayı başsız tarayıcıda açar       depoda           açılışta arka planda çeker
havuzu kurar, dosyaya yazar          yayında
```

---

## 1 · Depoyu hazırla

GitHub'da **herkese açık** (public) bir depo aç. Açık olması önemli: Actions
dakikaları public depolarda ücretsiz ve sınırsız, ayrıca `raw.githubusercontent.com`
adresi tarayıcıdan doğrudan okunabiliyor.

Dosya düzeni şöyle olmalı:

```
depo/
├─ index.html                    ← momentum-45.html'i BU İSİMLE koy
├─ tools/
│  └─ havuz-uret.mjs
└─ .github/
   └─ workflows/
      └─ havuz.yml
```

> `index.html` adı önemli — betik varsayılan olarak onu arıyor.
> Başka isim kullanacaksan `havuz.yml` içindeki `PD_SURE_DK` satırının altına
> `PD_SAYFA: "dosyaadi.html"` ekle.

## 2 · İlk turu elle başlat

Depoda **Actions** sekmesi → **Havuzu kur ve yayınla** → **Run workflow**.

İlk tur 464 hissenin tamamını gezer. Yahoo'nun hızına göre 1–5 saat sürebilir;
5 saatlik bütçe dolarsa iş kendini durdurur, o ana kadarki ilerlemeyi
`havuz.json` olarak işler ve **ertesi gece kaldığı yerden devam eder**. Yani
ilk hafta içinde havuz kendiliğinden tamamlanır, sizin bir şey yapmanız gerekmez.

Tur bitince depoda `havuz.json` görünür. Actions özetinde şunu yazar:

```
### Havuz durumu
- Dosya boyutu: 2.8M
- İlerleme: 464/464 hisse
- Dilim sayısı: 7
```

## 3 · Adresi telefona bir kez yapıştır

`havuz.json`'a tıkla → **Raw** düğmesi → adres çubuğundaki adresi kopyala.
Şu biçimde olacak:

```
https://raw.githubusercontent.com/KULLANICI/DEPO/main/havuz.json
```

Uygulamada **Havuz** bölümü → **☁️ Uzak havuz adresi** kutusuna yapıştır → **Kaydet**.

Bitti. Bundan sonra uygulama her açılışta arka planda kontrol eder; sunucudaki
kopya daha yeniyse sessizce indirir. Kullanıcı 3 dakika kullanıp çıkabilir.

---

## Sonraki günler

Zamanlanmış tur her gece **günlük ekleme** yapar (havuz tamamsa). Bu, sıfırdan
kurmaktan çok daha hızlıdır ve 5dk/15dk dilimlerinde örneklem biriktirir —
Yahoo bu dilimler için tek seferde en fazla ~60 gün veriyor, günlük ekleme ise
zamanla o tavanın üstüne çıkar.

**Ayda bir tam yenileme yapın.** Bedelsiz/temettü sonrası Yahoo eski fiyatları
geriye dönük düzeltir; eski sayaçlar düzeltilmemiş fiyattan hesaplanmıştır.
Actions → Run workflow → **Sıfırdan kur** kutusunu işaretle.

---

## Bilinmesi gerekenler

**Yahoo engelleyebilir.** Veri Yahoo Finance'in herkese açık uçlarından geliyor;
resmî bir anlaşma yok. Actions'ın IP'leri paylaşımlı olduğu için istekler
telefondan daha çok limite takılabilir. Betik hataları sayar ve devam eder;
"İlerleme" satırı 464'e ulaşmıyor ve hata sayısı yüksekse sebep budur. O
durumda `PD_SURE_DK` değerini düşürüp turu ikiye bölmek işe yarar.

**Ayarlar havuzu geçersiz kılar.** Havuz; sinyal modu, ufuk, hedef ve geçmiş
uzunluğu ayarlarına bağlıdır. Telefondaki ayarlar sunucudakinden farklıysa
uygulama havuzu indirir ama *kullanmaz* ve "ayarlar farklı" uyarısı verir.
Betik bunu kendisi de kontrol eder: imza değişmişse havuzu sıfırdan kurar.

**Dosya boyutu.** Tam havuz birkaç MB olur. Git her sürümü sakladığı için depo
zamanla büyür; yılda bir `git gc --aggressive` ya da geçmişi sıfırlamak
yeterlidir.

**Sunucu istemiyorsanız alternatif:** havuzu bir kez bilgisayarda (masaüstü
tarayıcıda, sekme açık) kurup **📦 Havuzlu HTML üret**'e basın. Havuz dosyanın
içine gömülür; o HTML'i kim açarsa havuzu hazır bulur. Otomatik tazelenmez ama
hiçbir kurulum gerektirmez.
